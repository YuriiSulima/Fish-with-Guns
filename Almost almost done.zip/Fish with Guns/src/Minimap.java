import java.awt.Graphics;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Minimap extends JPanel implements Drawable {
    //to finish
    private Pair position;
    private Pair size;
    private boolean miniMapAllowed = true;
    public void draw(Graphics g){
        // replace with the background of the minimap
        if (miniMapAllowed){
        g.setColor(Color.getHSBColor(90f / 360f, 1f, 1f));
        g.drawImage(Figures.minimap_Image,(int)position.getX(), (int)position.getY(), (int)size.getX(), (int)size.getY(),null);
        this.drawObjects(g);
    }
    }       
    public void setMiniMapAllowed(boolean allowed){
        this.miniMapAllowed = allowed;
    } 
    public void drawObjects(Graphics g){
        for (EntityObj entity : Main.entities) {
            if ((entity.getPosition().getX() > Main.hero.getPosition().getX() - Main.SCREEN_WIDTH /1.5) &&
            (entity.getPosition().getX() < Main.hero.getPosition().getX() + Main.SCREEN_WIDTH /1.5) &&
            (entity.getPosition().getY() > Main.hero.getPosition().getY() - Main.SCREEN_HEIGHT /1.5) &&
            (entity.getPosition().getY() < Main.hero.getPosition().getY() + Main.SCREEN_HEIGHT /1.5)){
                double scalePosX = entity.getPosition().getX() / Main.hero.getPosition().getX() *size.getX() - this.size.getX()/2;
                double scalePosY = entity.getPosition().getY() / Main.hero.getPosition().getY() * size.getY() - this.size.getY()/2;
                if (entity.classifier == Classifier.ROCK){
                    g.drawImage(Figures.minimap_o,(int)(scalePosX + this.position.getX() ), (int)(scalePosY + this.position.getY()), 25, 25 ,null);
                }
                else if (entity.classifier == Classifier.ENEMY){
                    g.drawImage(Figures.minimap_e,(int)(scalePosX + this.position.getX() ), (int)(scalePosY + this.position.getY()),25, 25 ,null);

                }
                else if(entity.classifier == Classifier.DUNGEON){
                    g.drawImage(Figures.minimap_domain,(int)(scalePosX + this.position.getX() ), (int)(scalePosY + this.position.getY()),25, 25 ,null);

                }
                else if (entity.classifier == Classifier.HERO){
                    g.drawImage(Figures.minimap_sal,(int)(scalePosX + this.position.getX() ), (int)(scalePosY + this.position.getY()), 25, 25 ,null);
                }
                else if(entity.classifier == Classifier.WEAPON){
                    g.drawImage(Figures.minimap_g,(int)(scalePosX + this.position.getX() ), (int)(scalePosY + this.position.getY()), 25, 25 ,null);
                }
                else if (entity.classifier == Classifier.DEFAULT){
                    g.drawImage(Figures.minimap_c,(int)(scalePosX + this.position.getX() ), (int)(scalePosY + this.position.getY()),25, 25 ,null);
                }
               
                }
            }
        }
        
    
    public Minimap(JPanel mainWindow, Camera cam){
        JPanel minimap = new JPanel();
        setLayout(null);
        this.position = cam.position;
        this.size = new Pair(200,200);
        minimap.setBounds((int)position.getX(),(int)position.getY(),(int)size.getX(),(int)size.getY());
        mainWindow.add(minimap);
        
    }
    public static void main(String[] args) {
        
    }
}

