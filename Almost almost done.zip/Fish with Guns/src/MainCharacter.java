import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.nio.Buffer;
import java.util.ArrayList;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Graphics;

public class MainCharacter extends Character{
    private Camera cam;
    private boolean weaponEquipped; 
    private Weapon weapon;
    private double endurance = 100;
    private ArrayList<Weapon> weapons; 
    private int currentWeapon = -1;
    public MainCharacter(){
        super();
        weapons = new ArrayList<Weapon>();
    } 
    public MainCharacter(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image, Classifier c){
        super(health, position, velocity, acceleration, collider, image, c);
        weapons = new ArrayList<Weapon>();

    }
    public MainCharacter(int health, Pair position, Pair collider, BufferedImage image){
        super(health, position, collider, image);
        weapons = new ArrayList<Weapon>();

    }
    public void setCamera(Camera cam){
        this.cam = cam;
    }
    public void setImage(BufferedImage image){
        this.image = image;
    }
    public void addWeapon(Weapon weapon){
        weapons.add(weapon);
        currentWeapon += 1;
        this.weaponEquipped = true;
    }
    public void changeWeapon(){
        if (currentWeapon < weapons.size() - 1){
            currentWeapon++;
            this.setWeapon(weapons.get(currentWeapon));
            this.setImage(weapon.image);   
            this.collider = new Pair(weapon.image.getWidth() / 2, weapon.image.getHeight() / 2);         
            weaponEquipped = true;
            if (right && this.getVelocity().getX() < 0) {
                flipX();
                right = false;
            } 
            else if (!right && this.getVelocity().getX() > 0) {
                flipX();
                right = true;
            } 
        }
        else{
            currentWeapon = -1;
            weaponEquipped = false;
        }
    }
    public void setWeapon(Weapon weapon){
        this.weapon = weapon;
    }
    public Weapon getWeapon(){
        if (weapons != null && currentWeapon != -1){
            return weapons.get(currentWeapon);
        }
        return null;
    }
    public double getEndurance(){
        return endurance;
    }
    public void setEndurance(double endurance){
        this.endurance = endurance;
    }
    public void draw(Graphics g){
        if (!weaponEquipped){
          setIdleImage();
        }
        super.draw(g);


    }
    private void setIdleImage(){
        if (Main.TIME % 5000 < 2000 && this.getVelocity().getX() <= 0) this.setImage(Figures.sal_dl); 
        else if (Main.TIME % 5000 < 3000 && this.getVelocity().getX() <= 0) this.setImage(Figures.sal_l); 
        else if (Main.TIME % 5000 < 4000 && this.getVelocity().getX() <= 0) this.setImage(Figures.sal_ul); 
        else if (Main.TIME % 5000 < 5000 && this.getVelocity().getX() <= 0) this.setImage(Figures.sal_u); 

        if (Main.TIME % 5000 < 2000 && this.getVelocity().getX() > 0) {
            this.setImage(Figures.sal_dl); flipX();
        }
        else if (Main.TIME % 5000 < 3000 && this.getVelocity().getX() > 0){
            this.setImage(Figures.sal_l); flipX();
        }
        else if (Main.TIME % 5000 < 4000 && this.getVelocity().getX() > 0) {
            this.setImage(Figures.sal_ul); flipX();
        }
        else if (Main.TIME % 5000 < 5000 && this.getVelocity().getX() > 0) {
            this.setImage(Figures.sal_u); flipX();
        }
        this.collider = new Pair(Figures.sal_dl.getWidth(),Figures.sal_dl.getHeight());
    }
    public void collide(PowerUp powerUp){
        if (this.position.getX() < powerUp.position.getX() + powerUp.collider.getX() &&
        this.position.getX() + this.collider.getX() > powerUp.position.getX() &&
        this.position.getY() < powerUp.position.getY() + powerUp.collider.getY() &&
        this.position.getY() + this.collider.getY() > powerUp.position.getY() && !powerUp.collected) {   
        powerUp.image = null;
        powerUp.collected = true;
        powerUp.collider = new Pair();
        this.health += 500;
        if (this.health > 5000) this.health = 5000;
    }
}
    public void collide(Location loc){
        if (this.position.getX() < loc.position.getX() + loc.collider.getX()*2 &&
        this.position.getX() + this.collider.getX() > loc.position.getX() &&
        this.position.getY() < loc.position.getY() + loc.collider.getY()*2 &&
        this.position.getY() + this.collider.getY() > loc.position.getY())  {   
            loc.teleport(this);
        }
}
    public void shoot(double x, double y){
        this.weapon.shoot(x,y);
    }
    public static void main(String[] args) {
        
    }
}