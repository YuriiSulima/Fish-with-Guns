import java.util.List;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import java.awt.Graphics;

public abstract class Weapon extends EntityObj implements Drawable{

    protected double damage;
    protected double rate;
    protected BufferedImage image;
    protected Pair position;
    protected Pair collider; 
    protected boolean picked;
    protected int index = 0;
    protected MainCharacter hero;
    private int ammo = 10;
    private boolean isAllowedDraw = true;
    private Bullet[] bullets;

    public Weapon(Pair position, double damage, double rate, BufferedImage image, MainCharacter hero){
        this.damage = damage;
        this.hero = hero;
        this.rate = rate;
        this.image = image;
        this.position = position;
        this.bullets = new Bullet[ammo];
        this.initAmmo();
        this.collider = new Pair(image.getWidth(), image.getHeight());
    }
    public Weapon(Pair position, double damage, double rate, Pair collider, BufferedImage image, MainCharacter hero){
        this(position, damage, rate, image, hero);
        this.collider = collider;
    }
    public Pair getPosition(){
        return this.position;
    }
    public double getDamage(){
        return damage;
    }
    public void draw(Graphics g){
        if (isAllowedDraw) g.drawImage(image, (int)position.getX(), (int)position.getY(),(int)collider.getX(),(int)collider.getY(), null);
    }
    public void shoot(double x, double y){
        if (bullets[index] != null){
            // 8 segments
            System.out.println(index);
            this.bullets[index].setAllowedDraw(true);
            double scaleX = (double) hero.getPosition().getX() / Main.WORLD_WIDTH  ;
            double scaleY = (double)  hero.getPosition().getY() / Main.WORLD_HEIGHT;
            double X = (Main.SCREEN_WIDTH* scaleX);
            double Y = (Main.SCREEN_HEIGHT* scaleY);
            double dx = X - x; // screen x 
            double dy = Y - y;

            double posX = hero.getPosition().getX();
            double posY = hero.getPosition().getY();
            bullets[index].position = new Pair(posX,posY);
            //relative positions on screen
            double fishX=Main.SCREEN_WIDTH/2 - Main.SCREEN_WIDTH / 7;
            double fishY=Main.SCREEN_HEIGHT/2 - Main.SCREEN_HEIGHT / 7;
            //these are at angles

            if ((x>fishX-50)&&x<fishX+50 &&y>fishY){
                // should go up
                bullets[index].setVelocity(new Pair(0,1000));
                bullets[index].setImage(Figures.smallBulletImageDown);

            }
            else if ((x>fishX-50)&&x<fishX+50){
                bullets[index].setVelocity(new Pair(01,-1000));
                bullets[index].setImage(Figures.smallBulletImageUp);
                System.out.println("called");
            }
            else if (x<fishX&&y<fishY-50){
                bullets[index].setVelocity(new Pair(-1000,-1000));
                bullets[index].setImage(Figures.smallBulletImageUpLeft);
            }
            else if (x>fishX&&y<fishY-50){
                bullets[index].setVelocity(new Pair(1000,-1000));
                bullets[index].setImage(Figures.smallBulletImageUpRight);
                //bullets[index].setImage(Figures.smallBulletImageUpLeft);
            }
            else if (x<fishX-50&&y>fishY+50){
                bullets[index].setVelocity(new Pair(-1000,1000));
                bullets[index].setImage(Figures.smallBulletImageDownLeft);
            }
            else if (x>fishX&&y>fishY+50){
                bullets[index].setVelocity(new Pair(1000,1000));
                //bullets[index].setImage(Figures.smallBulletImageDownLeft);
                bullets[index].setImage(Figures.smallBulletImageDownRight);
            }
            else if ((y>fishY-50)&&y<fishY+50 &&x>fishX){
                bullets[index].setVelocity(new Pair(1000,01));
                bullets[index].setImage(Figures.smallBulletImageLeft);

            }
            else if ((y>fishY-50)&&y<fishY+50 &&x<fishX){
                bullets[index].setVelocity(new Pair(-1000,01));
                bullets[index].setImage(Figures.smallBulletImageRight);

            }
        
           
            index++;
            if (index == ammo-1) {
                for (Bullet bullet : bullets) {
                    bullet.setAllowedDraw(false);
                    bullet.collider = new Pair(bullet.image.getWidth()*16, bullet.image.getHeight()*16);       
                         }
                index = 0;
                 
            }
                //
        }
    }
    public void initAmmo(){
        for (int i = 0; i < bullets.length; i++) {
            bullets[i] = new Bullet(this.damage,Figures.smallBulletImageLeft, (Character)this.hero);
        }
    }
    public List<Bullet> getBullets(){
        return Arrays.asList(bullets);
    }
    public void pickedUp(MainCharacter hero){
            if (this.position.getX() < hero.position.getX() + hero.collider.getX() &&
            this.position.getX() + this.collider.getX() > hero.position.getX() &&
            this.position.getY() < hero.position.getY() + hero.collider.getY() &&
            this.position.getY() + this.collider.getY() > hero.position.getY() && isAllowedDraw) {
                isAllowedDraw = false;
                hero.addWeapon(this);
                hero.setWeapon(this);
                this.initAmmo();
                this.position = new Pair(hero.getPosition().getX(), hero.getPosition().getY());
                if (hero.velocity.getX() > 0) hero.setRight(false);
                else if (hero.velocity.getX() < 0) hero.setRight(true);
                picked = true;
            }
        
    }  
     public static void main(String[] args) {
    }
}