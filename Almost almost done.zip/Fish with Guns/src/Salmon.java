import java.awt.image.BufferedImage;
import java.awt.Graphics;
import javax.swing.*;
import java.awt.*;
public class Salmon extends Enemy{
    GameLost lost;
    private boolean attacked;
    private MainCharacter hero; 

    public Salmon(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image, Classifier c){
        super(health, position, velocity, acceleration, collider, image, c);
    }
    public Salmon(int health, Pair position, Pair collider, BufferedImage image, Classifier c){
        super(health, position, new Pair(), new Pair(), collider, image, c);
    }
    public Salmon(){
        super();
       
    }
    public void draw(Graphics g){
        super.draw(g); 
        if (attacked){
            g.setColor(Color.RED);
            g.setFont(new Font("Times New Roman", 36, 36));
            g.drawString("DANGER!!!", (int)hero.getPosition().getX(), (int)(hero.getPosition().getY() ));
            attacked = false;
        }
        }
    public void follow(MainCharacter hero){
        if (this.position.getX() < hero.position.getX() + hero.collider.getX()*2 &&
        this.position.getX() + this.collider.getX()*2 > hero.position.getX() &&
        this.position.getY() < hero.position.getY() + hero.collider.getY()*2 &&
        this.position.getY() + this.collider.getY()*2 > hero.position.getY() && this.image != Figures.puffedImage) {
            this.hero = hero;
            if (this.position.getX() + hero.collider.getX()/2. < hero.position.getX()){
                this.velocity.setX(Main.SPEED);
            }
            else if (this.position.getX() > hero.position.getX() + hero.collider.getX()/2.){
                this.velocity.setX(-Main.SPEED);
            }
            else {
                this.velocity.setX(0);
            }
            if (this.position.getY() + hero.collider.getY()/2.< hero.position.getY()){
                this.velocity.setY(Main.SPEED);
            }
            else if (this.position.getY() > hero.position.getY() + hero.collider.getY()/2.){
                this.velocity.setY(-Main.SPEED);
            }
            else {
                this.velocity.setY(0);
            }
            //attack simplified
            if (this.position.getX() < hero.position.getX() + hero.collider.getX() &&
            this.position.getX() + this.collider.getX() > hero.position.getX() &&
            this.position.getY() < hero.position.getY() + hero.collider.getY() &&
            this.position.getY() + this.collider.getY() > hero.position.getY()) {
                double actualDMG = damage * Math.random(); // randomized damage 
                hero.health -= actualDMG;
                attacked = true;
                if (!hero.isAlive() && lost== null){
                    System.out.println("You died!");
                    lost = new GameLost();
                }
            }
        }
    }
}
