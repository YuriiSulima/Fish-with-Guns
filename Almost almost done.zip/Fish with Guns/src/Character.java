import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.Graphics;
import java.awt.Color;

public class Character extends EntityObj implements Updatable{
    protected int health;
    protected transient Pair acceleration; 
    protected transient boolean right;

    public Character(){
        this(0,new Pair(0,0),new Pair(0,0),new Pair(0,0), new Pair(0,0), null, Classifier.DEFAULT);
    }
    public Character(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image, Classifier c){
        super(position, collider, image, c);
        this.health = health;
        this.velocity = velocity;
        this.acceleration = acceleration;
    }
    public Character(int health, Pair position, Pair velocity, Pair collider, BufferedImage image) {   
        this(health, position, velocity, new Pair(0,0), collider, image, Classifier.DEFAULT);
    }
    public Character(int health, Pair position, Pair collider, BufferedImage image){
        this(health, position, new Pair(0,0), new Pair(0,0), collider, image, Classifier.DEFAULT);
    }
    public boolean isAlive(){
        return health >= 0;
    }
    public void decreaseHealth(double factor){
        this.health -= factor;
    }
    public Pair getPosition(){
        return position;
    }
    public void setPosition(Pair position){
        this.position = position;
    }
    public Pair getVelocity(){
        return velocity;
    }
    public void setVelocity(Pair velocity){
        this.velocity = velocity;
    }
    public void setVelocity(double velocity, boolean horizontal){
        if (horizontal){
            this.velocity.setX(velocity);
        }
        else{
            this.velocity.setY(velocity);
        }
    }
   
    @Override
    public void draw(Graphics g){
        if (this.getHealth() > 0){
            if (this.velocity.getX() < 0){
                // Flip the image horizontally 
                if (right && !Main.paused){
                        flipX();
                        right = false;
                }          
            } else if (this.velocity.getX() > 0){
                // Flip the image horizontally 
                if (!right && !Main.paused){
                    flipX();
                    right = true;
                }
                
            }
        super.draw(g);
        }
    }
    public void setRight(boolean right){
        this.right = right;
    }
    protected void flipX(){
        AffineTransform tx = AffineTransform.getScaleInstance(-1, 1);
        tx.translate(-this.image.getWidth(null), 0);
        AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
        this.image = op.filter(this.image, null);
    }
    public void update(double time){
        position.add(velocity.multiply(time));
    }
     public void save(String filename) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeInt(health);
            out.writeDouble(position.getX());
            out.writeDouble(position.getY());
            out.close();
            System.out.println("Game saved successfully!");

        } catch (IOException e) {
            System.out.println("Error saving game: " + e.getMessage());
        }
    }
    public void load(String filename) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            this.health = in.readInt();
            this.position.setX(in.readDouble());
            this.position.setY(in.readDouble());
        } catch (IOException e) {
            System.out.println("Error loading game: " + e.getMessage());
        }
    }
    public int getHealth(){
        return health;
    }
    

    public static void main(String[] args) {
        
    }
    
}
  

