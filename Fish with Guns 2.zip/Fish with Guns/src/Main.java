import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.border.Border;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Taskbar.Feature;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
public class Main extends JPanel implements KeyListener, MouseListener{
    /*
        This is the main game. From this the game will start 
    
     */

    public static boolean paused = false;

    public static MainCharacter hero;

    private static Camera cam;
    private static TileMap map;
    private static Minimap miniMap;
    private static Healthbar healthBar;
    private static Main window;
    private static Handgun handgun;
    private static Ak ak;
    private static boolean weaponOn;


    private static HashMap<String, Integer> objects;

    public static final int SCREEN_WIDTH = 1920;
    public static final int SCREEN_HEIGHT = 1024;
    public static final int WORLD_WIDTH = (int)(200 * 64);
    public static final int WORLD_HEIGHT = (int)(200 * 64);
    public static final int FPS = 60;
    public static int TIME; 

    public static int SPEED = 200;

    public static ArrayList<Character> characters = new ArrayList<Character>();
    public static ArrayList<Drawable> toDraw = new ArrayList<Drawable>();
    public static ArrayList<EntityObj> entities = new ArrayList<EntityObj>();
    public static ArrayList<Enemy> enemies = new ArrayList<Enemy>();
    public static ArrayList<Bullet> bullets = new ArrayList<Bullet>();
    public static ArrayList<Weapon> weapons = new ArrayList<Weapon>();
    

    public void addNotify() {
        super.addNotify();
        requestFocus();
    }
    //Drawing the map
    public void paintComponent(Graphics g) {
        super.paintComponent(g);    
        resetCamera(g);
        draw(g);
    }
    public static void main(String[] args) {
        window = new Main();
        Figures fig = new Figures();
        map = new TileMap(); 
        objects = new HashMap<String, Integer>();
        createMap();
        window.startGame();
        JFrame frame = new JFrame("Fish with Guns");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(window, BorderLayout.CENTER);
        frame.add(miniMap, BorderLayout.EAST);
        frame.add(healthBar,BorderLayout.WEST);
        frame.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
        frame.setPreferredSize(new Dimension(SCREEN_WIDTH,SCREEN_HEIGHT));
        frame.setIconImage(Figures.heroImage);
        frame.setName("FISH WITH GUNS");
        frame.pack();        
        frame.setVisible(true);
        
        window.run();
    }
    public Main(){
        this.addKeyListener(this);
        this.addMouseListener(this);
    }

    public void run()
    {
        while(true){
            if (!paused) {
                updateWorld();
            }
            repaint();
            try{
                Thread.sleep(1000 / FPS);
                TIME += 1000 / FPS;
            }
            catch(InterruptedException e){}
        }

    }
    public static void draw(Graphics g){
        for (Drawable drawable : toDraw) {
            drawable.draw(g);
        }
    }
    public static void resetCamera(Graphics g){
        g.translate(-(int)cam.getX(), -(int)cam.getY());
    }
    public void startGame(){  
        //Initiliazing
        //Characters
        hero = new MainCharacter(5000, new Pair(WORLD_WIDTH/2.,WORLD_HEIGHT/2.), new Pair(0,0),new Pair(0,0), new Pair(Figures.heroImage.getWidth(),Figures.heroImage.getHeight()), 
                                Figures.heroImage, Classifier.HERO);
        cam = new Camera(new Pair(hero.getPosition().getX() - SCREEN_WIDTH / 2., hero.getPosition().getY() - SCREEN_HEIGHT / 2.), 
                                new Pair(SCREEN_WIDTH,SCREEN_HEIGHT), new Pair(WORLD_WIDTH, WORLD_HEIGHT),hero);
        handgun = new Handgun(new Pair(WORLD_WIDTH/2. + 400,WORLD_HEIGHT/2. + 200),1000, 30, Figures.handgunImage, hero);
        ak = new Ak(new Pair(WORLD_WIDTH/2. +500,WORLD_HEIGHT/2. + 200),1000, 60, Figures.akImage, hero);

        miniMap = new Minimap(window, cam);
        healthBar = new Healthbar(window, cam, hero);
        hero.setCamera(cam);

        //change something about handgun
        weapons.add(handgun);
        weapons.add(ak);
        // characters arraylist for update 
        characters.add(hero);
         // objects arraylist for collision

        entities.addAll(characters);
        // Drawables arraylist for draw 
        toDraw.add(map);
        toDraw.addAll(entities);
        toDraw.addAll(weapons);
        toDraw.addAll(bullets);
        toDraw.add(miniMap);
        toDraw.add(healthBar);
    

    }
    public static void createMap(){
        //objects 
        objects.put("rock1", 10);
        objects.put("rock2", 10);
        objects.put("rock3", 10);
        objects.put("rock4", 10);
        objects.put("stalactite1",20);
        objects.put("stalactite2",20);
        objects.put("stalactite3",20);
        objects.put("stalactite4",20);
        objects.put("caveentrance",5);

        //enemies
        objects.put("babyshrimp",10);
        objects.put("bigshrimp",10);
        objects.put("crab",10);
        objects.put("puffered",10);
        objects.put("salmon",10);
        objects.put("school",10);

        for (Map.Entry<String, Integer> object : objects.entrySet()) {
            String k = object.getKey();
            int v = object.getValue();
            for (int i = 0; i < v; i++) {
                double x = Math.random()*WORLD_WIDTH;
                double y = Math.random()*WORLD_HEIGHT;   
                switch (k) {
                    case "rock1":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.rock1Image.getWidth(), Figures.rock1Image.getHeight()), 
                                                    Figures.rock1Image, Classifier.ROCK));
                        break;
                    case "rock2":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.rock2Image.getWidth(), Figures.rock2Image.getHeight()), 
                                                    Figures.rock2Image, Classifier.ROCK));
                        break;
                    case "rock3":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.rock3Image.getWidth(), Figures.rock3Image.getHeight()), 
                                                    Figures.rock3Image, Classifier.ROCK));
                        break;
                    case "rock4":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.rock4Image.getWidth(), Figures.rock4Image.getHeight()), 
                                                    Figures.rock4Image, Classifier.ROCK));
                        break;
                    case "caveentrance":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.caveEntranceImage.getWidth(), Figures.caveEntranceImage.getHeight()), 
                                                    Figures.caveEntranceImage, Classifier.DUNGEON));
                        break;
                    case "stalactite1":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.stalactite1Image.getWidth(), Figures.stalactite1Image.getHeight()), 
                                                    Figures.stalactite1Image, Classifier.ROCK));
                        break;
                    case "stalactite2":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.stalactite2Image.getWidth(), Figures.stalactite2Image.getHeight()), 
                                                    Figures.stalactite2Image, Classifier.ROCK));
                        break;
                    case "stalactite3":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.stalactite3Image.getWidth(), Figures.stalactite3Image.getHeight()), 
                                                    Figures.stalactite3Image, Classifier.ROCK));
                        break;
                    case "stalactite4":
                        entities.add(new EntityObj(new Pair(x,y), new Pair(Figures.stalactite4Image.getWidth(), Figures.stalactite4Image.getHeight()), 
                                                    Figures.stalactite4Image, Classifier.ROCK));
                        break;
                    case "babyshrimp":
                        enemies.add(new Enemy(3000,new Pair(x,y), new Pair(Figures.babyShrimpImage.getWidth(), Figures.babyShrimpImage.getHeight()), 
                                                    Figures.babyShrimpImage, Classifier.ENEMY));
                        break;
                    case "bigshrimp":
                        enemies.add(new Enemy(5000,new Pair(x,y), new Pair(Figures.bigShrimpImage.getWidth(), Figures.bigShrimpImage.getHeight()), 
                                                    Figures.bigShrimpImage, Classifier.ENEMY));
                        break;
                    case "crab":
                        enemies.add(new Enemy(10000,new Pair(x,y), new Pair(Figures.crabImage.getWidth(), Figures.crabImage.getHeight()), 
                                                    Figures.crabImage, Classifier.ENEMY));
                        break;
                    case "puffered":
                        enemies.add(new Enemy(1000,new Pair(x,y), new Pair(Figures.puffedImage.getWidth(), Figures.puffedImage.getHeight()), 
                                                    Figures.puffedImage, Classifier.ENEMY));
                        break;
                    case "salmon":
                        enemies.add(new Enemy(20000,new Pair(x,y), new Pair(Figures.salmonImage.getWidth(), Figures.salmonImage.getHeight()), 
                                                    Figures.salmonImage, Classifier.ENEMY));
                        break;
                    case "school":
                        enemies.add(new Enemy(5000,new Pair(x,y), new Pair(Figures.schoolImage.getWidth(), Figures.schoolImage.getHeight()), 
                                                    Figures.schoolImage, Classifier.ENEMY));
                        break;
                }
            }

        }
        characters.addAll(enemies);
    }
    public static void updateWorld(){
        for (Enemy enemy : enemies) {
            enemy.follow(hero);
        }
        for (Character character : characters) {
            character.update(1 / (double)FPS);
        }
        
            healthBar.update(cam);
        for (int i = 0; i < characters.size(); i++) {
            for (int j = i+1; j < entities.size(); j++) {
                entities.get(i).collide(entities.get(j));
            }
        }
        
        for (Weapon weapon : weapons) {
            weapon.pickedUp(hero);
        }
        if (hero.getWeapon() != null && !weaponOn ) {
            bullets.addAll(hero.getWeapon().getBullets());
            toDraw.addAll(bullets);
            weaponOn = true;
        }
        if (bullets.size() != 0) {
            for (Bullet bullet : bullets) {
                bullet.update( 1 / (double) FPS);
            }
            for (Bullet bullet : bullets) {
                for (Enemy enemy : enemies) {
                    if (bullet.collide(enemy)){
                        enemy = null;
                        bullet.setAllowedDraw(false);
                    }
                    
                }
            }
        }
       
        cam.update(new Pair(hero.getPosition().getX() - SCREEN_WIDTH / 2., hero.getPosition().getY() - SCREEN_HEIGHT / 2.));

    }
    @Override
    public void keyPressed(KeyEvent e) { 
        int c = e.getKeyCode();
        if ((c == KeyEvent.VK_A || c == KeyEvent.VK_LEFT)&& hero.getPosition().getX() > 0 ){
            hero.setVelocity(-SPEED,true);
        }
        if ((c == KeyEvent.VK_D || c == KeyEvent.VK_RIGHT)&& hero.getPosition().getX() > 0 ){
            hero.setVelocity(SPEED,true);
        }
        if ((c == KeyEvent.VK_W || c == KeyEvent.VK_UP)&& hero.getPosition().getY() > 0){
            hero.setVelocity(-SPEED,false);
        }
        if ((c == KeyEvent.VK_S || c == KeyEvent.VK_DOWN)&& hero.getPosition().getY() < WORLD_HEIGHT){
            hero.setVelocity(SPEED,false);
        } 
       
        if (c == KeyEvent.VK_MINUS){
            cam.zoomOut();
        }
        if (c == KeyEvent.VK_PLUS){
            cam.zoomIn();   
        }
        if (c == KeyEvent.VK_Q){
            if (hero.getWeapon() != null){
                hero.getWeapon().drop();
                bullets.clear();
                weaponOn = false;
            }
        }
        if (c == KeyEvent.VK_F6){
            for (int i = 0; i < characters.size(); i++) {
                characters.get(i).load("Save_" + i + "_.dat");
            }
        } 
        if (c == KeyEvent.VK_F5){
            for (int i = 0; i < characters.size(); i++) {
                characters.get(i).save("Save_" + i + "_.dat");
            }
        } 
        if (c == KeyEvent.VK_P){
            if (!paused) paused = true;
            else {
                paused = false;
            }
        }
        if (c == KeyEvent.VK_SHIFT){
            hero.setVelocity(new Pair(hero.getVelocity().getX()*2, hero.getVelocity().getY()*2));
         }
         if (c == KeyEvent.VK_CONTROL){
            hero.setVelocity(new Pair(hero.getVelocity().getX()/2, hero.getVelocity().getY()/2));
         }
    }
        
    
    @Override
    public void keyReleased(KeyEvent e) {
        int c = e.getKeyCode();
        if (c == KeyEvent.VK_SHIFT){
            SPEED = Main.SPEED;
        }
        hero.setVelocity(new Pair());

    }
    @Override
    public void keyTyped(KeyEvent e) {
        int c = e.getKeyCode();
       
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        int c = e.getButton();  
        if (c == 1){
            int posX = e.getX();
            int posY = e.getY();
            if (hero.getWeapon() != null){
                hero.shoot(posX, posY);
            }
        }
        else if (c == 2){
        }
        else if (c == 3){
        }
    }
    @Override
    public void mousePressed(MouseEvent e) {
       

    }
    @Override
    public void mouseReleased(MouseEvent e) {
        
    }
    @Override
    public void mouseEntered(MouseEvent e) {
        
    }
    @Override
    public void mouseExited(MouseEvent e) {
       
    }
}
