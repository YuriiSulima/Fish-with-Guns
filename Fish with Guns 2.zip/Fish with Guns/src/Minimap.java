import java.awt.Graphics;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Minimap extends JPanel implements Drawable {
    //to finish
    private Pair position;
    private Pair size;
    public void draw(Graphics g){
        // replace with the background of the minimap
        g.setColor(Color.getHSBColor(90f / 360f, 1f, 1f));
        g.drawRect((int)position.getX(), (int)position.getY(), (int)size.getX(), (int)size.getY());
        g.setColor(Color.getHSBColor(120f / 360f, 1f, 0.5f));
        g.fillRect((int)position.getX(), (int)position.getY(), (int)size.getX(), (int)size.getY());
        this.drawObjects(g);

    }        
    public void drawObjects(Graphics g){
        for (EntityObj entity : Main.entities) {
            if ((entity.getPosition().getX() > Main.hero.getPosition().getX() - Main.SCREEN_WIDTH / 2) &&
            (entity.getPosition().getX() < Main.hero.getPosition().getX() + Main.SCREEN_WIDTH / 2) &&
            (entity.getPosition().getY() > Main.hero.getPosition().getY() - Main.SCREEN_HEIGHT / 2) &&
            (entity.getPosition().getY() < Main.hero.getPosition().getY() + Main.SCREEN_HEIGHT / 2)){
                if (entity.classifier == Classifier.ROCK){
                    g.setColor(Color.getHSBColor(45f / 360f, 1f, 1f));
                }
                else if (entity.classifier == Classifier.ENEMY){
                    g.setColor(Color.getHSBColor(90f / 360f, 1f, 1f));

                }
                else if(entity.classifier == Classifier.DUNGEON){
                    g.setColor(Color.getHSBColor(120f / 360f, 1f, 1f));

                }
                else if(entity.classifier == Classifier.WEAPON){
                    g.setColor(Color.getHSBColor(160f / 360f, 1f, 1f));

                }
                double scalePosX = entity.getPosition().getX() / this.position.getX();
                double scalePosY = entity.getPosition().getY() / this.position.getY();
                g.fillRect((int)(scalePosX + this.position.getX() + this.size.getX()/2), (int)(scalePosY + this.position.getY() + this.size.getY()/2), 25, 25);
               // g.fillRect((int)(entity.getPosition().getX() + (int)entity.getCollider().getX()/2), (int)(entity.getPosition().getY()+ (int)entity.getCollider().getY()/2), 25, 25);

                }
            }
           
        }
        
    
    public Minimap(JPanel mainWindow, Camera cam){
        JPanel minimap = new JPanel();
        setLayout(null);
        this.position = cam.position;
        this.size = new Pair(200,200);
        minimap.setBounds((int)position.getX(),(int)position.getY(),(int)size.getX(),(int)size.getY());
        mainWindow.add(minimap);
        
    }
    public static void main(String[] args) {
        
    }
}

