import java.util.List;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import java.awt.Graphics;

public  class Weapon implements Drawable{

    protected double damage;
    protected double rate;
    protected BufferedImage image;
    protected Pair position;
    protected Pair collider; 
    protected boolean picked;
    protected int index = 0;
    protected MainCharacter hero;
    private int ammo = 30;
    private Bullet[] bullets = new Bullet[ammo];

    public Weapon(Pair position, double damage, double rate, BufferedImage image, MainCharacter hero){
        this.damage = damage;
        this.hero = hero;
        this.rate = rate;
        this.image = image;
        this.position = position;
        this.bullets = new Bullet[ammo];
        this.initAmmo();
        this.collider = new Pair(image.getWidth(), image.getHeight());
    }
    public Weapon(Pair position, double damage, double rate, Pair collider, BufferedImage image, MainCharacter hero){
        this(position, damage, rate, image, hero);
        this.collider = collider;
    }
    public double getDamage(){
        return damage;
    }
    public void draw(Graphics g){
        g.drawImage(image, (int)position.getX(), (int)position.getY(),(int)collider.getX(),(int)collider.getY(), null);
    }
    public void shoot(double x, double y){
        if (bullets.length != 0 && bullets[index] != null){
            // 8 segments
            System.out.println(index);
            this.bullets[index].setAllowedDraw(true);
            double scaleX = (double) hero.getPosition().getX() / Main.WORLD_WIDTH  ;
            double scaleY = (double)  hero.getPosition().getY() / Main.WORLD_HEIGHT;
            double X = (Main.SCREEN_WIDTH* scaleX);
            double Y = (Main.SCREEN_HEIGHT* scaleY);
            double dx = X - x; // screen x 
            double dy = Y - y;

            double posX = hero.getPosition().getX();
            double posY = hero.getPosition().getY();

            double xbound = 50;
            double ybound = 50;
            bullets[index].position = new Pair(posX,posY);
            if (dx > xbound && dy > ybound){
                bullets[index].setVelocity(new Pair(-200,-200));
                bullets[index].setImage(Figures.smallBulletImageUpLeft);
            }
            else if (dx < -xbound && dy > ybound){
                bullets[index].setVelocity(new Pair(200,-200));
                bullets[index].setImage(Figures.smallBulletImageUpRight);
            }
            else if (dx > xbound && dy < -ybound){
                bullets[index].setVelocity(new Pair(-200,200));
                bullets[index].setImage(Figures.smallBulletImageDownLeft);
            }
            else if (dx < -xbound && dy < -ybound){
                bullets[index].setVelocity(new Pair(200,200));
                bullets[index].setImage(Figures.smallBulletImageDownRight);
            }
            else if (Math.abs(dx) <= xbound && dy > 0){
                bullets[index].setVelocity(new Pair(0,-200));
                bullets[index].setImage(Figures.smallBulletImageUp);
            }
            else if (Math.abs(dx) <= xbound && dy < 0){
                bullets[index].setVelocity(new Pair(0,200));
                bullets[index].setImage(Figures.smallBulletImageDown);

            }
            else if (Math.abs(dy) <= ybound && dx > 0){
                bullets[index].setVelocity(new Pair(-200,0));
                bullets[index].setImage(Figures.smallBulletImageRight);

            }
            else if (Math.abs(dy) <= y && dx < 0){
                bullets[index].setVelocity(new Pair(200,0));
                bullets[index].setImage(Figures.smallBulletImageLeft);

            }
            index++;
            if (index == ammo-1) {
                for (Bullet bullet : bullets) {
                    bullet.setAllowedDraw(false);
                    bullet.collider = new Pair(bullet.image.getWidth()*16, bullet.image.getHeight()*16);       
                         }
                index = 0; 
            }
                //
        }
    }
    public void initAmmo(){
        for (int i = 0; i < bullets.length; i++) {
            bullets[i] = new Bullet(this.damage,Figures.smallBulletImageLeft, this.hero);
        }
    }
    public List<Bullet> getBullets(){
        return Arrays.asList(bullets);
    }
    public void pickedUp(MainCharacter hero){
        if (!picked){
            if (this.position.getX() < hero.position.getX() + hero.collider.getX() &&
            this.position.getX() + this.collider.getX() > hero.position.getX() &&
            this.position.getY() < hero.position.getY() + hero.collider.getY() &&
            this.position.getY() + this.collider.getY() > hero.position.getY()) {
                this.image = null;
                hero.setWeapon(this);
                this.position = new Pair(hero.getPosition().getX(), hero.getPosition().getY());
                if (hero.velocity.getX() > 0) hero.setRight(true);
                else if (hero.velocity.getX() < 0) hero.setRight(false);
                picked = true;
            }
        }
        else{
            if (this.position.getX() < hero.position.getX() + hero.collider.getX() &&
            this.position.getX() + this.collider.getX() > hero.position.getX() &&
            this.position.getY() < hero.position.getY() + hero.collider.getY() &&
            this.position.getY() + this.collider.getY() > hero.position.getY()) {
                this.image = null;
                hero.setWeapon(this);
                this.position = new Pair(hero.getPosition().getX(), hero.getPosition().getY());
                if (hero.velocity.getX() > 0) hero.setRight(true);
                else if (hero.velocity.getX() < 0) hero.setRight(false);
                picked = true;
            }
        }
       
    }  
    public void drop(){
        if (picked){
                hero.setImage(Figures.heroImage);
                hero.setWeapon(null);
                this.position = new Pair(hero.getPosition().getX() + 200, hero.getPosition().getY() + 200);
                picked = false;
            }
        }
     public static void main(String[] args) {
    }
}