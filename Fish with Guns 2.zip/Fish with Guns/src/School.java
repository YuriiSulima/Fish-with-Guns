public class School extends Enemy{
    
}
