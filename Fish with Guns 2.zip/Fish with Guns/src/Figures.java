import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Graphics2D;

public class Figures{

    public static BufferedImage heroImage;  
    public static BufferedImage mapImage1;
    public static BufferedImage mapImage2;
    public static BufferedImage rock1Image;  
    public static BufferedImage rock2Image;  
    public static BufferedImage rock3Image;  
    public static BufferedImage rock4Image;
    public static BufferedImage caveEntranceImage;    
    public static BufferedImage stalactite1Image;  
    public static BufferedImage stalactite2Image;  
    public static BufferedImage stalactite3Image;  
    public static BufferedImage stalactite4Image;  
    public static BufferedImage stalagmiteImage;  
    public static BufferedImage babyShrimpImage;  
    public static BufferedImage bigShrimpImage;  
    public static BufferedImage crabImage;  
    public static BufferedImage salmonImage;  
    public static BufferedImage schoolImage;  
    public static BufferedImage puffedImage;  
    public static BufferedImage unpuffedImage;  
    public static BufferedImage akImage;  
    public static BufferedImage bazookaImage;  
    public static BufferedImage doublehandgunImage;  
    public static BufferedImage handgunImage;  
    public static BufferedImage akwfishImage;  
    public static BufferedImage bazookawfishImage;  
    public static BufferedImage handgunwfishImage;  
    public static BufferedImage doublehandgunwImage;  
    public static BufferedImage smallBulletImageLeft; 
    public static BufferedImage smallBulletImageRight;  
    public static BufferedImage smallBulletImageUp;  
    public static BufferedImage smallBulletImageDown;  
    public static BufferedImage smallBulletImageUpLeft;  
    public static BufferedImage smallBulletImageUpRight;  
    public static BufferedImage smallBulletImageDownLeft;  
    public static BufferedImage smallBulletImageDownRight;  



    public static BufferedImage bigBulletImage;  
    
    public Figures(){
        try{
            heroImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/hero.png"));
            mapImage1 = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/tilemap/water_draft_2.png"));
            mapImage2 = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/tilemap/water_draft_2_2.png"));
            rock1Image = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/rock1.png"));
            rock2Image = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/rock2.png"));
            rock3Image = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/rock3.png"));
            rock4Image = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/rock4.png"));
            stalactite1Image = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/stalactite1.png"));
            stalactite2Image = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/stalactite2.png"));
            stalactite3Image = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/stalactite3.png"));
            stalactite4Image = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/stalactite4.png"));
            stalagmiteImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/stalagmite.png"));
            babyShrimpImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/babyshrimp.png"));
            bigShrimpImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/bigshrimp.png"));
            crabImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/crab.png"));
            salmonImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/salmon.png"));
            schoolImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/school.png"));
            puffedImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/puffered.png"));
            unpuffedImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/unpuffed.png"));
            akImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/weapons/ak.png"));
            bazookaImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/weapons/bazooka.png"));
            doublehandgunImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/weapons/doublehandgun.png"));
            handgunImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/weapons/handgun.png"));
            akwfishImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/akwfish.png"));
            bazookawfishImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/bazookawfish.png"));
            doublehandgunwImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/doublehandgunwfish.png"));
            handgunwfishImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/handgunwfish.png"));
            caveEntranceImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/caveentrance.png"));
            smallBulletImageLeft = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/smallBulletLeft.png"));
            smallBulletImageRight = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/smallBulletRight.png"));
            smallBulletImageDown = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/smallBulletDown.png"));
            smallBulletImageUp = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/smallBulletUp.png"));
            smallBulletImageUpLeft = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/smallBulletUpLeft.png"));
            smallBulletImageDownLeft = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/smallBulletDownLeft.png"));
            smallBulletImageUpRight = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/smallBulletUpRight.png"));
            smallBulletImageDownRight = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/objects/smallBulletDownRight.png"));

        }
        catch (IOException e){
            e.getStackTrace();
        }
    }
    public static void main(String[] args) {
        Figures fig = new Figures();
    }
}