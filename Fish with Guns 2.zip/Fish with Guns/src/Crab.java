public class Crab extends Enemy{
    
}
