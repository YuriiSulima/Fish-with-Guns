import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.nio.Buffer;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class MainCharacter extends Character{
    private Camera cam;
    private boolean weaponEquipped; 
    private Weapon weapon;
    public MainCharacter(){
        super();
       
    } 
    public MainCharacter(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image, Classifier c){
        super(health, position, velocity, acceleration, collider, image, c);
    }
    public MainCharacter(int health, Pair position, Pair collider, BufferedImage image){
        super(health, position, collider, image);
    }
    public void setCamera(Camera cam){
        this.cam = cam;
    }
    public void setImage(BufferedImage image){
        this.image = image;
        this.weaponEquipped = true;
    }
    public void setWeapon(Weapon weapon){
        this.weapon = weapon;
    }
    public Weapon getWeapon(){
        return this.weapon;
    }
    public void collide(PowerUp powerUp){
        if (this.position.getX() < powerUp.position.getX() + powerUp.collider.getX() &&
        this.position.getX() + this.collider.getX() > powerUp.position.getX() &&
        this.position.getY() < powerUp.position.getY() + powerUp.collider.getY() &&
        this.position.getY() + this.collider.getY() > powerUp.position.getY() && !powerUp.collected) {   
        powerUp.image = null;
        powerUp.collected = true;
        powerUp.collider = new Pair();
        this.health += 500;
        if (this.health > 5000) this.health = 5000;
    }
}
    public void shoot(double x, double y){
        this.weapon.shoot(x,y);
    }
    public static void main(String[] args) {
        
    }
}