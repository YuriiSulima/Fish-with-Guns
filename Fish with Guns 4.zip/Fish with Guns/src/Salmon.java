import java.awt.image.BufferedImage;
public class Salmon extends Enemy{
    GameLost lost;
    public Salmon(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image, Classifier c){
        super(health, position, velocity, acceleration, collider, image, c);
    }
    public Salmon(int health, Pair position, Pair collider, BufferedImage image, Classifier c){
        super(health, position, new Pair(), new Pair(), collider, image, c);
    }
    public Salmon(){
        super();
       
    }
    public void follow(MainCharacter hero){
        if (this.position.getX() < hero.position.getX() + hero.collider.getX()*2 &&
        this.position.getX() + this.collider.getX()*2 > hero.position.getX() &&
        this.position.getY() < hero.position.getY() + hero.collider.getY()*2 &&
        this.position.getY() + this.collider.getY()*2 > hero.position.getY() && this.image != Figures.puffedImage) {
            if (this.position.getX() + hero.collider.getX()/2. < hero.position.getX()){
                this.velocity.setX(Main.SPEED);
            }
            else if (this.position.getX() > hero.position.getX() + hero.collider.getX()/2.){
                this.velocity.setX(-Main.SPEED);
            }
            else {
                this.velocity.setX(0);
            }
            if (this.position.getY() + hero.collider.getY()/2.< hero.position.getY()){
                this.velocity.setY(Main.SPEED);
            }
            else if (this.position.getY() > hero.position.getY() + hero.collider.getY()/2.){
                this.velocity.setY(-Main.SPEED);
            }
            else {
                this.velocity.setY(0);
            }
            //attack simplified
            if (this.position.getX() < hero.position.getX() + hero.collider.getX() &&
            this.position.getX() + this.collider.getX() > hero.position.getX() &&
            this.position.getY() < hero.position.getY() + hero.collider.getY() &&
            this.position.getY() + this.collider.getY() > hero.position.getY()) {
                double actualDMG = damage * Math.random(); // randomized damage 
                hero.health -= actualDMG;
                if (!hero.isAlive() && lost== null){
                    System.out.println("You died!");
                    lost = new GameLost();
                }
            }
        }
    }
}
