import java.awt.image.BufferedImage;
public class PufferFish extends Enemy {
    public PufferFish(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image, Classifier c){
        super(health, position, velocity, acceleration, collider, image, c);
    }
    public PufferFish(int health, Pair position, Pair collider, BufferedImage image, Classifier c){
        super(health, position, new Pair(), new Pair(), collider, image, c);
    }
    public PufferFish(){
        super();
       
    }
    public void follow(MainCharacter hero){
        super.follow(hero);
        if (this.position.getX() < hero.position.getX() + hero.collider.getX()*2 &&
        this.position.getX() + this.collider.getX()*2 > hero.position.getX() &&
        this.position.getY() < hero.position.getY() + hero.collider.getY()*2 &&
        this.position.getY() + this.collider.getY()*2 > hero.position.getY() && this.image != Figures.puffedImage) {
            this.image = Figures.puffedImage;
            this.collider = new Pair(this.image.getWidth(), this.image.getHeight());
        }
    }
}
