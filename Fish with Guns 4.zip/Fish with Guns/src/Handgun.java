import java.awt.image.BufferedImage;
public class Handgun extends Weapon{
    public Handgun(Pair position, double damage, double rate, BufferedImage image, MainCharacter hero){
        super(position, damage, rate, image, hero);
    }
    public Handgun(Pair position, double damage, double rate,  Pair collider,BufferedImage image,MainCharacter hero){
        super(position, damage, rate, collider, image, hero);
    }
    @Override
    public void drop(MainCharacter hero){
        super.drop(hero);
        this.image = Figures.handgunImage;
    }
    public void pickedUp(MainCharacter hero){
        super.pickedUp(hero);
        if (picked){
            this.hero.setImage(Figures.handgunwfishImage);
            this.hero.collider = new Pair(Figures.handgunwfishImage.getWidth() / 2,Figures.handgunwfishImage.getHeight() /2);
            this.hero.setRight(false);
        }
    }  
    public static void main(String[] args) {
        
    }

}
