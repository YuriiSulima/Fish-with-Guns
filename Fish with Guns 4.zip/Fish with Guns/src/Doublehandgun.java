import java.awt.image.BufferedImage;
public class Doublehandgun extends Weapon{
    public Doublehandgun(Pair position, double damage, double rate, BufferedImage image, MainCharacter hero){
        super(position, damage, rate, image, hero);
    }
    @Override
    public void drop(MainCharacter hero){
        super.drop(hero);
        this.image = Figures.doublehandgunImage;
    }
    public void pickedUp(MainCharacter hero){
        // collision with player
        super.pickedUp(hero);
        if (picked){
            this.hero.setImage(Figures.doublehandgunwImage);
            this.hero.collider = new Pair(Figures.doublehandgunwImage.getWidth() / 2., Figures.doublehandgunwImage.getHeight() / 2.);
            this.hero.setRight(false);
        }
    }
}
