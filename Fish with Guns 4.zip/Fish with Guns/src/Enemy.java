import java.awt.image.BufferedImage;
public class Enemy extends Character{
    protected double damage = 10;
    GameLost lost;
    public Enemy(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image, Classifier c){
        super(health, position, velocity, acceleration, collider, image, c);
    }
    public Enemy(int health, Pair position, Pair collider, BufferedImage image, Classifier c){
        super(health, position, new Pair(), new Pair(), collider, image, c);
    }
    public Enemy(){
        super();
       
    }
    public void follow(MainCharacter hero){
        if (this.position.getX() < hero.position.getX() + hero.collider.getX()*2 &&
        this.position.getX() + this.collider.getX()*2 > hero.position.getX() &&
        this.position.getY() < hero.position.getY() + hero.collider.getY()*2 &&
        this.position.getY() + this.collider.getY()*2 > hero.position.getY()) {
            if (this.position.getX() + hero.collider.getX()/2. < hero.position.getX()){
                this.velocity.setX(Main.SPEED/3);
            }
            else if (this.position.getX() > hero.position.getX() + hero.collider.getX()/2.){
                this.velocity.setX(-Main.SPEED/3);
            }
            else {
                this.velocity.setX(0);
            }
            if (this.position.getY() + hero.collider.getY()/2.< hero.position.getY()){
                this.velocity.setY(Main.SPEED/3);
            }
            else if (this.position.getY() > hero.position.getY() + hero.collider.getY()/2.){
                this.velocity.setY(-Main.SPEED/3);
            }
            else {
                this.velocity.setY(0);
            }
            //attack simplified
            if (this.position.getX() < hero.position.getX() + hero.collider.getX() &&
            this.position.getX() + this.collider.getX() > hero.position.getX() &&
            this.position.getY() < hero.position.getY() + hero.collider.getY() &&
            this.position.getY() + this.collider.getY() > hero.position.getY()) {
                double actualDMG = damage * Math.random(); // randomized damage 
                hero.health -= actualDMG;
                if (!hero.isAlive() && lost==null){
                    System.out.println("You died!");
                    lost = new GameLost();
                }
            }

        }
    }
    public void setDamage(double damage){
        this.damage = damage;
    }
    public double getDamage(){
        return this.damage;
    }
    public static void main(String[] args) {
        
    }
}
