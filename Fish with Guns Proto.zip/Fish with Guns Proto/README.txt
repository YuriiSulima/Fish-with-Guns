Welcome to Fish with Guns!

This is the first ever fish-type game.
You control Sal the Sardine. He is practicing his second ammendment rights in the deep blue sea.

Story:
Outside of sovereign waters (>12 nautical miles from shore) for no particular reason, someone drops a handful of weapons over the side.
Now Sal the Sardine is at the bottom of the food chain, and this particular stretch of ocean is run by gangs of larger fish who love to eat sardines.
Unfortunately, our hero, Sal, is a sardine.
A sardine with a mission: Survive.

Controls:
W/Up Move Up
A/Left Move Left
S/Down Move Down
D/Right Move Right
Click Shoot
Mouse Aim
P pause
F5 Save State
F6 Load Last Save State

To Start: Run from main.java
