public class PufferFish extends Enemy {
    
}
