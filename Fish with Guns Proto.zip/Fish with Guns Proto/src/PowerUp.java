import java.awt.image.BufferedImage;

public class PowerUp extends EntityObj{
    public boolean collected;
    public PowerUp (Pair position, BufferedImage image,Classifier c){
        super(position, new Pair(25,25), image , c);
    }
    @Override
    public void collide(EntityObj other) {
        if (this.position.getX() < other.position.getX() + other.collider.getX() &&
        this.position.getX() + this.collider.getX() > other.position.getX() &&
        this.position.getY() < other.position.getY() + other.collider.getY() &&
        this.position.getY() + this.collider.getY() > other.position.getY()) {   
            this.image = null;
         }
}
}  
