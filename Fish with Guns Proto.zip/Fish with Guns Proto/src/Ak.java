import java.awt.image.BufferedImage;
public class Ak extends Weapon{
    public Ak(Pair position, double damage, double rate, BufferedImage image, MainCharacter hero){
        super(position, damage, rate, image, hero);
    }
    public Ak(Pair position, double damage, double rate,  Pair collider,BufferedImage image,MainCharacter hero){
        super(position, damage, rate,collider ,image,hero);
    }
    public void drop(){
        super.drop();
        this.image = Figures.akImage;
    }
    public void pickedUp(MainCharacter hero){
        super.pickedUp(hero);
        if (picked){
            this.hero.setImage(Figures.akwfishImage);
            this.hero.collider = new Pair(Figures.akwfishImage.getWidth(),Figures.akwfishImage.getHeight());
            this.hero.setRight(false);
        }
    }
    public static void main(String[] args) {
        
    }
}
