public class PowerUp {
    
}
