public class Salmon extends Enemy{
    
}
