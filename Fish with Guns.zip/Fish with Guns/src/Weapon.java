public class Weapon {
    
}
