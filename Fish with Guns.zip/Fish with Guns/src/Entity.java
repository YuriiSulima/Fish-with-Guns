import java.awt.image.BufferedImage;

public class Entity {
    protected Pair position;
    protected Pair collider;
    protected BufferedImage image;
    
    public Entity(Pair position, Pair collider, BufferedImage image){
        this.position = position;
        this.collider = collider;
        this.image = image;
    }
    public Entity(){
        this.position = new Pair();
        this.collider = new Pair();
        this.image = null;
    }
    public static void main(String[] args) {
        
    }
}
