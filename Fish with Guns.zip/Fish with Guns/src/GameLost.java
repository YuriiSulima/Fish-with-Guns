import javax.swing.*;
import java.awt.*;
public class GameLost extends JFrame {
    public GameLost() {
        setTitle("Game Over");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Figures fig = new Figures();
        JLabel lostLabel = new JLabel("You lost", SwingConstants.CENTER);
        Font font = new Font("Arial", Font.BOLD, 20);
        lostLabel.setFont(font);
        add(lostLabel);
        JLabel background = new JLabel(new ImageIcon(Figures.heroImage));
        background.setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        background.add(lostLabel, BorderLayout.CENTER);
        setContentPane(background);
        setVisible(true);
    }

    public static void main(String[] args) {
        new GameLost();
    }
}
