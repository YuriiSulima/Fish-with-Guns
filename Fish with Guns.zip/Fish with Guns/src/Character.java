import java.awt.image.BufferedImage;

import java.awt.Graphics;

public class Character extends Entity implements Updatable{
    protected int health;
    protected Pair velocity; 
    protected Pair acceleration; 

    public Character(){
        this(0,new Pair(0,0),new Pair(0,0),new Pair(0,0), new Pair(0,0), null);
    }
    public Character(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image){
        super(position, collider, image);
        this.health = health;
        this.velocity = velocity;
        this.acceleration = acceleration;
    }
    public Character(int health, Pair position, Pair velocity, Pair collider, BufferedImage image) {   
        this(health, position, velocity, new Pair(0,0), collider, image);
    }
    public Character(int health, Pair position, Pair collider, BufferedImage image){
        this(health, position, new Pair(0,0), new Pair(0,0), collider, image);
    }
    public boolean isAlive(){
        return health <= 0;
    }
    public void draw (Graphics g){
        g.drawImage(image, (int)position.getX(),(int) position.getY(), (int) collider.getX(), (int)collider.getY(), null);
    }
    public Pair getPosition(){
        return position;
    }
    public void setPosition(Pair position){
        this.position = position;
    }
    public Pair getVelocity(){
        return velocity;
    }
    public void setVelocity(Pair velocity){
        this.velocity = velocity;
    }
    public void setVelocity(double velocity, boolean horizontal){
        if (horizontal){
            this.velocity.setX(velocity);
        }
        else{
            this.velocity.setY(velocity);
        }
    }

    public void update(double time){
        position.add(velocity.multiply(time));
    }
    

    public static void main(String[] args) {
        
    }
}
