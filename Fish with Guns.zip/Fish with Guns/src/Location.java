import java.awt.Graphics;
import java.awt.image.BufferedImage;
public class Location extends EntityObj {

    public Location(Pair position, Pair collider, BufferedImage image, Classifier c){
        super(position, collider, image, c);
    }
    public Location(){
        super();
    }
    public void teleport(MainCharacter hero){
        hero.position = this.position;
        System.out.println("called");
    }
}
