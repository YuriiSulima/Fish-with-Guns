import java.awt.image.BufferedImage;
public class Handgun extends Weapon{
    public Handgun(Pair position, double damage, double rate, BufferedImage image, MainCharacter hero){
        super(position, damage, rate, image, hero);
    }
   
    public static void main(String[] args) {
        
    }
}
