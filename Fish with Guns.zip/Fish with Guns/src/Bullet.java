import java.awt.image.BufferedImage;
import java.nio.Buffer;
import java.awt.Graphics;

public class Bullet extends EntityObj implements Updatable{
    private double damage;
    private double time;
    private boolean allowedDraw;
    public Bullet(double damage, BufferedImage image, MainCharacter hero){
        super(new Pair(hero.getPosition().getX(),hero.getPosition().getY()), new Pair(image.getWidth()*16, image.getHeight()*16), image, Classifier.DEFAULT);
        this.damage = damage;
        this.time = 0;
    }
    public void draw(Graphics g){
        if (allowedDraw){
            super.draw(g);
        }
    }
    public boolean collide(Enemy other){
        if (this.position.getX() < other.position.getX() + other.collider.getX() &&
            this.position.getX() + this.collider.getX() > other.position.getX() &&
            this.position.getY() < other.position.getY() + other.collider.getY() &&
            this.position.getY() + this.collider.getY() > other.position.getY()) {
                other.decreaseHealth(damage);
                System.out.println(other.getHealth());
                if (other.getHealth() < 0){
                    other.setDamage(0);
                    
                }
                return true;
        }
        return false;
    }
    public void isDestroyed(double time){
        if (this.time > time){
            this.damage = 0;
            this.image = null;
        }
    }
    public void setImage(BufferedImage image){
        this.image = image;
    }
    public void update(double time){
        this.position.add(velocity.multiply(time));
    }
    public void setAllowedDraw(boolean allowed){
        this.allowedDraw = allowed;
    }
    public static void main(String[] args) {
        
    }
}
