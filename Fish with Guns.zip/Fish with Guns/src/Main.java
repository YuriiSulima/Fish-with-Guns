import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JPanel;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
public class Main extends JPanel implements KeyListener, MouseListener{
    /*
        This is the main game. From this the game will start 
    
     */
    private static BufferedImage heroImage;
    private static MainCharacter hero;
    private static Camera cam;
    private static TileMap map;

    private static final int SCREEN_WIDTH = 800;
    private static final int SCREEN_HEIGHT = 600;
    private static final int WORLD_WIDTH = 1024;
    private static final int WORLD_HEIGHT = 768;
    private static final int FPS = 60;

    private static ArrayList<Character> characters = new ArrayList<Character>();
    public void addNotify() {
        super.addNotify();
        requestFocus();
    }
    //Drawing the map
    public void paintComponent(Graphics g) {
        super.paintComponent(g);    
        resetCamera(g);
        draw(g);
    }
    public static void main(String[] args) {
        Main window = new Main();
        map = new TileMap(); 
        window.startGame();

        JFrame frame = new JFrame("Fish with Guns");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(window, BorderLayout.CENTER);
        frame.setSize(WORLD_WIDTH, WORLD_HEIGHT);
        frame.setPreferredSize(new Dimension(WORLD_WIDTH,WORLD_HEIGHT));
        frame.pack();        
        frame.setVisible(true);
        window.run();
    }
    public Main(){
        this.addKeyListener(this);
        this.addMouseListener(this);
    }
    public void run()
    {
        while(true){
            updateWorld();
            repaint();
            try{
                Thread.sleep(1000 / FPS);
            }
            catch(InterruptedException e){}
        }

    }
    public static void draw(Graphics g){
        map.drawMap(g);
        hero.draw(g);
    }
    public static void resetCamera(Graphics g){
        // Ensure camera stays within bounds of the game world
        g.translate(-(int)cam.getX(), -(int)cam.getY());
    }
    public void startGame(){
        try {
            //read an image from the folder
            heroImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/characters/hero.png"));
        }
        catch (IOException e) {
            e.printStackTrace();
        }   
        hero = new MainCharacter(100, new Pair(WORLD_WIDTH/2.,WORLD_HEIGHT /2.), new Pair(0,0),new Pair(0,0), new Pair(200,100), heroImage);
        cam = new Camera(new Pair(hero.getPosition().getX() - SCREEN_WIDTH / 2., hero.getPosition().getY() - SCREEN_HEIGHT / 2.), new Pair(SCREEN_WIDTH,SCREEN_HEIGHT));
        hero.setCamera(cam);
        characters.add(hero);
        
    }
    public static void updateWorld(){
        for (Character character : characters) {
            character.update(1 / (double)FPS);
        }
        cam.update(new Pair(hero.getPosition().getX() - SCREEN_WIDTH / 2., hero.getPosition().getY() - SCREEN_HEIGHT / 2.));

    }
    @Override
    public void keyPressed(KeyEvent e) {
        char c = e.getKeyChar();
        if (c == 'a'){
            hero.setVelocity(-200,true);
        }
        else if (c == 'd'){
            hero.setVelocity(200,true);
        }
        else if (c == 'w'){
            hero.setVelocity(-200,false);
        }
        else if (c == 's'){
            hero.setVelocity(200,false);
        }
        
   
    }
    @Override
    public void keyReleased(KeyEvent e) {
        hero.setVelocity(new Pair());

    }
    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();

    }
    @Override
    public void mouseClicked(MouseEvent e) {
        int c = e.getButton();
        if (c == 1){
            int posX = e.getX();
            int posY = e.getY();
            hero.setPosition(new Pair(posX, posY));
        }
        else if (c == 2){
        }
        else if (c == 3){
        }
    }
    @Override
    public void mousePressed(MouseEvent e) {
       

    }
    @Override
    public void mouseReleased(MouseEvent e) {
        
    }
    @Override
    public void mouseEntered(MouseEvent e) {
        
    }
    @Override
    public void mouseExited(MouseEvent e) {
       
    }
}
