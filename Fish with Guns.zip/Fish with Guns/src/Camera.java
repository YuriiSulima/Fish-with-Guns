public class Camera{
    Pair position;
    Pair size;
    public Camera(Pair position, Pair size){
        this.position = position;
        this.size = size;
    }
    public String toString(){
        return "Position: (" + position.getX() + ", " + position.getY() + ")\n";
    }
    public void update(Pair position){
        this.position = position;
    }
    public double getX(){
        return position.getX();
    }
    public double getY(){
        return position.getY();
    }
    public static void main(String[] args) {
        
    }
}
