public enum Classifier {
    HERO,
    ROCK,
    ENEMY,
    DUNGEON,
    BOSS,
    DEFAULT
}
