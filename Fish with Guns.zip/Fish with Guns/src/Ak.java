import java.awt.image.BufferedImage;
public class Ak extends Weapon{
    public Ak(Pair position, double damage, double rate, BufferedImage image, MainCharacter hero){
        super(position, damage, rate, image, hero);
    }
    public void pickedUp(MainCharacter hero){
        // collision with player
        if (!picked){
            if (this.position.getX() < hero.position.getX() + hero.collider.getX() &&
            this.position.getX() + this.collider.getX() > hero.position.getX() &&
            this.position.getY() < hero.position.getY() + hero.collider.getY() &&
            this.position.getY() + this.collider.getY() > hero.position.getY()) {
                image = null;
                hero.setImage(Figures.akwfishImage);
                if (hero.velocity.getX() >= 0) hero.setRight(false);
                else if (hero.velocity.getX() < 0) hero.setRight(true);
                picked = true;

            }
        }
    }
    public static void main(String[] args) {
        
    }
}
