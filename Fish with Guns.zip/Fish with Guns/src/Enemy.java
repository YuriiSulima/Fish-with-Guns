// """
//         The name stands for itself 
//         """;

public class Enemy extends Character{
    
}
