import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import javax.swing.JPanel;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

// """
//         This class reads a map from the image and converts to 2d array which can later be used 
//         to make physical structures in the game
//         """;

public class TileMap extends JPanel{
    private BufferedImage mapImage;
    private int width;
    private int height;
    private int colorIndex;
    private Tile[][] pixels;
    public double tileSize = 128; // Size of each cell
    private int numRows;
    private int numCols;
    // Dictionary of colors on the map
    //HashMap<Integer, Integer> colorCounts = new HashMap<Integer,Integer>();


    public TileMap(){
        try {
            //read an image from the folder
            mapImage = ImageIO.read(new File("/Users/yuriisulima/Desktop/Fish with Guns/images/tilemap/water1.jpg"));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
            // Get the width and height of the image
            //width = mapImage.getWidth();
            //height = mapImage.getHeight();

            width = 1024;
            height = 768; 
            
            // Create a 2D array to store the pixel values
            numRows = height;
            numCols = width;

            pixels = new Tile[numCols][numRows];
            
            // Loop through each pixel and store its RGB value in the array

            for (int col = 0; col < numCols; col++) {
                for (int row = 0; row < numRows; row++) {
                    //int rgb = mapImage.getRGB(x, y);
                    pixels[col][row] = new Tile(new Pair(col*tileSize,row*tileSize), tileSize, mapImage);
                    //counts amount of colors in image
                    // if (colorCounts.containsKey(rgb)) {
                    //     colorCounts.put(rgb, colorCounts.get(rgb) + 1);
                    // } else {
                    //     colorCounts.put(rgb, 1);
                    // }
                    
                }
            }
    
    }
    public void addNotify() {
        super.addNotify();
        requestFocus();
    }
    //Drawing the map
    public void paintComponent(Graphics g) {
        super.paintComponent(g);                    
    }
   public void drawMap(Graphics g){
    // Loop through the array and draw each cell
    for (int row = 0; row < numRows; row++) {
        for (int col = 0; col < numCols; col++) {
            Tile tile = pixels[col][row];
            tile.draw(g);
        }
    }
   }

    
}
