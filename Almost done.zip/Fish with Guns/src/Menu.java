import javax.swing.*;
import java.awt.*;
public class Menu extends JFrame {
    public Menu() {
        setTitle("Menu");
        setSize(800, 600);
        Figures fig = new Figures();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Menu();
    }
}
