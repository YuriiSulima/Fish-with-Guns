public enum Classifier {
    HERO,
    ROCK,
    ENEMY,
    DUNGEON,
    WEAPON,
    BOSS,
    POWERUP,
    DEFAULT
}
