import javax.swing.*;
import java.awt.*;
public class GameLost extends JFrame {
    public GameLost() {
        setTitle("Game Over");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Figures fig = new Figures();
        JLabel background = new JLabel(new ImageIcon(Figures.endBgImage.getScaledInstance(800, 600, Image.SCALE_SMOOTH)));
        background.setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        setContentPane(background);
        setVisible(true);
    }

    public static void main(String[] args) {
        new GameLost();
    }
}
