import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.*;
import java.awt.*;
public class Enemy extends Character{
    protected double damage = 10;
    protected boolean attacked;
    protected MainCharacter hero; 
    GameLost lost;
    public Enemy(int health, Pair position, Pair velocity, Pair acceleration, Pair collider, BufferedImage image, Classifier c){
        super(health, position, velocity, acceleration, collider, image, c);
    }
    public Enemy(int health, Pair position, Pair collider, BufferedImage image, Classifier c){
        super(health, position, new Pair(), new Pair(), collider, image, c);
    }
    public Enemy(){
        super();
       
    }
    public void draw(Graphics g){
        super.draw(g); 
        if (attacked){
            g.setColor(Color.RED);
            g.setFont(new Font("Times New Roman", 36, 36));
            g.drawString("DANGER!!!", (int)hero.getPosition().getX(), (int)(hero.getPosition().getY() ));
            attacked = false;
        }
        }
    public void follow(MainCharacter hero){
        if (this.position.getX() < hero.position.getX() + hero.collider.getX()*2 &&
        this.position.getX() + this.collider.getX()*2 > hero.position.getX() &&
        this.position.getY() < hero.position.getY() + hero.collider.getY()*2 &&
        this.position.getY() + this.collider.getY()*2 > hero.position.getY()) {
            this.hero = hero;
            if (this.position.getX() + hero.collider.getX()/2. < hero.position.getX()){
                this.velocity.setX(Main.SPEED/3);
            }
            else if (this.position.getX() > hero.position.getX() + hero.collider.getX()/2.){
                this.velocity.setX(-Main.SPEED/3);
            }
            else {
                this.velocity.setX(0);
            }
            if (this.position.getY() + hero.collider.getY()/2.< hero.position.getY()){
                this.velocity.setY(Main.SPEED/3);
            }
            else if (this.position.getY() > hero.position.getY() + hero.collider.getY()/2.){
                this.velocity.setY(-Main.SPEED/3);
            }
            else {
                this.velocity.setY(0);
            }
            //attack simplified
            this.attack();

        }
    }
    protected void attack(){
        if (this.position.getX() < hero.position.getX() + hero.collider.getX() &&
            this.position.getX() + this.collider.getX() > hero.position.getX() &&
            this.position.getY() < hero.position.getY() + hero.collider.getY() &&
            this.position.getY() + this.collider.getY() > hero.position.getY()) {
                double actualDMG = damage * Math.random(); // randomized damage 
                hero.health -= actualDMG;
                attacked = true;
                if (!hero.isAlive() && lost==null){
                    lost = new GameLost();
                }
            }
    }
    public void setDamage(double damage){
        this.damage = damage;
    }
    public double getDamage(){
        return this.damage;
    }
    public static void main(String[] args) {
        
    }
}
